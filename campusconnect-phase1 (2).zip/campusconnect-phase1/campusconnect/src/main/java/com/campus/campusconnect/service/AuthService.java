package com.campus.campusconnect.service;

import com.campus.campusconnect.dto.*;
import com.campus.campusconnect.model.UserAccount;
import com.campus.campusconnect.repository.UserAccountRepository;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.util.Locale;
import java.util.UUID;

@Service
public class AuthService {
    private final UserAccountRepository repo;
    private final BCryptPasswordEncoder encoder = new BCryptPasswordEncoder();
    public AuthService(UserAccountRepository repo){this.repo=repo;}

    @Transactional
    public AuthResponse register(RegisterRequest r){
        String email=normalize(r.email()); String role=normalize(r.role());
        if(email.isBlank() || r.name()==null || r.name().isBlank() || r.password()==null || r.password().length()<8) throw new IllegalArgumentException("Name, email and a password of at least 8 characters are required.");
        if(!role.equals("student")&&!role.equals("faculty")&&!role.equals("admin")) throw new IllegalArgumentException("Invalid role.");
        if(repo.existsByEmailIgnoreCase(email)) throw new IllegalArgumentException("An account with this email already exists.");
        UserAccount u=new UserAccount(); u.setName(r.name().trim()); u.setEmail(email); u.setMobile(r.mobile()); u.setRole(role); u.setPasswordHash(encoder.encode(r.password()));
        u.setRollNo(r.rollNo()); u.setBranch(r.branch()); u.setSemester(r.semester()); u.setAcademicYear(r.academicYear()); u.setEmployeeId(r.employeeId()); u.setDepartment(r.department()); u.setDesignation(r.designation()); u.setAdminId(r.adminId());
        u.setAuthorizationStatus(role.equals("admin") ? "PENDING_APPROVAL" : "APPROVED");
        repo.save(u); return new AuthResponse(null, UserResponse.from(u));
    }

    @Transactional
    public AuthResponse login(AuthRequest r){
        UserAccount u=repo.findByEmailIgnoreCase(normalize(r.email())).orElseThrow(()->new IllegalArgumentException("Invalid email or password."));
        if(r.role()!=null && !normalize(r.role()).equals(u.getRole())) throw new IllegalArgumentException("Invalid email or password.");
        if(!encoder.matches(r.password(),u.getPasswordHash())) throw new IllegalArgumentException("Invalid email or password.");
        if("admin".equals(u.getRole()) && "PENDING_APPROVAL".equals(u.getAuthorizationStatus())) throw new IllegalArgumentException("Admin account is pending authorization.");
        String token=UUID.randomUUID().toString(); u.setSessionToken(token); repo.save(u); return new AuthResponse(token,UserResponse.from(u));
    }

    @Transactional(readOnly=true)
    public UserResponse byToken(String token){ return repo.findBySessionToken(token).map(UserResponse::from).orElseThrow(()->new IllegalArgumentException("Invalid or expired session.")); }

    @Transactional
    public void logout(String token){ repo.findBySessionToken(token).ifPresent(u->{u.setSessionToken(null);repo.save(u);}); }

    private String normalize(String s){return s==null?"":s.trim().toLowerCase(Locale.ROOT);}
}
