package com.campus.campusconnect.dto;
public record AuthResponse(String token, UserResponse user) {}
