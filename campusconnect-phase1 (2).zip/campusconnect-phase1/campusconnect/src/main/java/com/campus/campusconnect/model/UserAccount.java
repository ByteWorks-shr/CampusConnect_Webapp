package com.campus.campusconnect.model;

import jakarta.persistence.*;
import java.time.Instant;

@Entity
@Table(name = "users", uniqueConstraints = @UniqueConstraint(name = "uk_users_email", columnNames = "email"))
public class UserAccount {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @Column(nullable=false) private String name;
    @Column(nullable=false) private String email;
    private String mobile;
    @Column(nullable=false) private String passwordHash;
    @Column(nullable=false) private String role;
    private String rollNo;
    private String branch;
    private String semester;
    private String academicYear;
    private String employeeId;
    private String department;
    private String designation;
    private String adminId;
    private String authorizationStatus;
    private String profilePhoto;
    private String sessionToken;
    private Instant createdAt;

    @PrePersist void onCreate(){ if(createdAt==null) createdAt=Instant.now(); }
    public Long getId(){return id;} public void setId(Long v){id=v;}
    public String getName(){return name;} public void setName(String v){name=v;}
    public String getEmail(){return email;} public void setEmail(String v){email=v;}
    public String getMobile(){return mobile;} public void setMobile(String v){mobile=v;}
    public String getPasswordHash(){return passwordHash;} public void setPasswordHash(String v){passwordHash=v;}
    public String getRole(){return role;} public void setRole(String v){role=v;}
    public String getRollNo(){return rollNo;} public void setRollNo(String v){rollNo=v;}
    public String getBranch(){return branch;} public void setBranch(String v){branch=v;}
    public String getSemester(){return semester;} public void setSemester(String v){semester=v;}
    public String getAcademicYear(){return academicYear;} public void setAcademicYear(String v){academicYear=v;}
    public String getEmployeeId(){return employeeId;} public void setEmployeeId(String v){employeeId=v;}
    public String getDepartment(){return department;} public void setDepartment(String v){department=v;}
    public String getDesignation(){return designation;} public void setDesignation(String v){designation=v;}
    public String getAdminId(){return adminId;} public void setAdminId(String v){adminId=v;}
    public String getAuthorizationStatus(){return authorizationStatus;} public void setAuthorizationStatus(String v){authorizationStatus=v;}
    public String getProfilePhoto(){return profilePhoto;} public void setProfilePhoto(String v){profilePhoto=v;}
    public String getSessionToken(){return sessionToken;} public void setSessionToken(String v){sessionToken=v;}
    public Instant getCreatedAt(){return createdAt;} public void setCreatedAt(Instant v){createdAt=v;}
}
