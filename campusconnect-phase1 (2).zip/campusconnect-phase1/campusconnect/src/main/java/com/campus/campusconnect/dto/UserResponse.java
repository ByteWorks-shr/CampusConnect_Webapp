package com.campus.campusconnect.dto;

import com.campus.campusconnect.model.UserAccount;

public record UserResponse(Long id, String name, String email, String mobile, String role, String rollNo, String branch, String semester, String academicYear, String employeeId, String department, String designation, String adminId, String authorizationStatus, String profilePhoto) {
    public static UserResponse from(UserAccount u){ return new UserResponse(u.getId(),u.getName(),u.getEmail(),u.getMobile(),u.getRole(),u.getRollNo(),u.getBranch(),u.getSemester(),u.getAcademicYear(),u.getEmployeeId(),u.getDepartment(),u.getDesignation(),u.getAdminId(),u.getAuthorizationStatus(),u.getProfilePhoto()); }
}
