package com.campus.campusconnect.dto;
public record AuthRequest(String email, String password, String role) {}
