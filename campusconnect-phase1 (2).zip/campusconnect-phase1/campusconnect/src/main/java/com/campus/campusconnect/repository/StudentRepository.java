package com.campus.campusconnect.repository;

import com.campus.campusconnect.model.Student;
import org.springframework.data.jpa.repository.JpaRepository;

public interface StudentRepository extends JpaRepository<Student, Long> {

    Student findByEmailAndPasswordAndRole(String email, String password, String role);

    Student findByEmail(String email);
}