
package com.campus.campusconnect.repository;

import com.campus.campusconnect.model.PublicContent;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface PublicContentRepository
        extends JpaRepository<PublicContent, Long> {

    List<PublicContent> findByContentTypeIgnoreCaseAndPublishedTrueOrderByIdDesc(
            String contentType);
}
