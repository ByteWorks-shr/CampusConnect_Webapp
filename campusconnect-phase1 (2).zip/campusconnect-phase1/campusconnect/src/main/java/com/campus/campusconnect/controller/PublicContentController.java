
package com.campus.campusconnect.controller;

import com.campus.campusconnect.model.PublicContent;
import com.campus.campusconnect.repository.PublicContentRepository;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/public")
public class PublicContentController {

    private final PublicContentRepository repository;

    public PublicContentController(
            PublicContentRepository repository) {
        this.repository = repository;
    }

    @GetMapping("/home")
    public Map<String, Object> home() {
        return Map.of(
                "status", "ok",
                "message", "CampusConnect public API is running");
    }

    @GetMapping("/notices")
    public List<PublicContent> notices() {
        return getPublished("notice");
    }

    @GetMapping("/news")
    public List<PublicContent> news() {
        return getPublished("news");
    }

    @GetMapping("/events")
    public List<PublicContent> events() {
        return getPublished("event");
    }

    @GetMapping("/departments")
    public List<PublicContent> departments() {
        return getPublished("department");
    }

    @GetMapping("/courses")
    public List<PublicContent> courses() {
        return getPublished("course");
    }

    @GetMapping("/examinations")
    public List<PublicContent> examinations() {
        return getPublished("examination");
    }

    @GetMapping("/learning")
    public List<PublicContent> learning() {
        return getPublished("learning");
    }

    @GetMapping("/research")
    public List<PublicContent> research() {
        return getPublished("research");
    }

    @GetMapping("/gallery")
    public List<PublicContent> gallery() {
        return getPublished("gallery");
    }

    @GetMapping("/faqs")
    public List<PublicContent> faqs() {
        return getPublished("faq");
    }

    private List<PublicContent> getPublished(String type) {
        return repository
                .findByContentTypeIgnoreCaseAndPublishedTrueOrderByIdDesc(
                        type);
    }
}
