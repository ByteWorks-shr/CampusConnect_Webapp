package com.campus.campusconnect.dto;
public record RegisterRequest(String role, String name, String email, String mobile, String password, String rollNo, String branch, String semester, String academicYear, String employeeId, String department, String designation, String adminId, String authorizationStatus) {}
