package com.campus.campusconnect.service;

import com.campus.campusconnect.model.Student;
import com.campus.campusconnect.repository.StudentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class StudentService {

    @Autowired
    private StudentRepository studentRepository;

    // REGISTER
    public Student saveStudent(Student student) {
        return studentRepository.save(student);
    }

    // LOGIN
    public Student login(String email, String password, String role) {

        Student student = studentRepository
                .findByEmailAndPasswordAndRole(email, password, role);

        if (student != null) {
            return student;
        } else {
            throw new RuntimeException("Invalid Credentials");
        }
    }

    // GET STUDENT BY EMAIL
    public Student getUserByEmail(String email) {
        return studentRepository.findByEmail(email);
    }
}