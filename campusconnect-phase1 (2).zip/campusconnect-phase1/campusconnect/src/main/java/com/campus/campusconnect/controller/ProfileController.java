package com.campus.campusconnect.controller;

import com.campus.campusconnect.dto.UserResponse;
import com.campus.campusconnect.service.AuthService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api")
public class ProfileController {
    private final AuthService auth;
    public ProfileController(AuthService auth) { this.auth = auth; }

    @GetMapping("/student/profile")
    public ResponseEntity<?> student(@RequestHeader(value="Authorization", required=false) String h) {
        return profile(h, "student");
    }
    @GetMapping("/faculty/profile")
    public ResponseEntity<?> faculty(@RequestHeader(value="Authorization", required=false) String h) {
        return profile(h, "faculty");
    }
    @GetMapping("/admin/profile")
    public ResponseEntity<?> admin(@RequestHeader(value="Authorization", required=false) String h) {
        return profile(h, "admin");
    }

    private ResponseEntity<?> profile(String h, String expectedRole) {
        try {
            if (h == null || !h.startsWith("Bearer ")) throw new IllegalArgumentException("Authentication required.");
            UserResponse user = auth.byToken(h.substring(7).trim());
            if (!expectedRole.equalsIgnoreCase(user.role())) throw new IllegalArgumentException("You are not authorized for this profile.");
            return ResponseEntity.ok(user);
        } catch (IllegalArgumentException e) {
            return ResponseEntity.status(401).body(java.util.Map.of("message", e.getMessage()));
        }
    }
}
