package com.campus.campusconnect.controller;

import com.campus.campusconnect.dto.*;
import com.campus.campusconnect.service.AuthService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController @RequestMapping("/api/auth")
public class AuthController {
    private final AuthService auth;
    public AuthController(AuthService auth){this.auth=auth;}
    @PostMapping("/register") public ResponseEntity<?> register(@RequestBody RegisterRequest r){try{return ResponseEntity.ok(auth.register(r));}catch(IllegalArgumentException e){return ResponseEntity.badRequest().body(java.util.Map.of("message",e.getMessage()));}}
    @PostMapping("/login") public ResponseEntity<?> login(@RequestBody AuthRequest r){try{return ResponseEntity.ok(auth.login(r));}catch(IllegalArgumentException e){return ResponseEntity.status(401).body(java.util.Map.of("message",e.getMessage()));}}
    @GetMapping("/me") public ResponseEntity<?> me(@RequestHeader(value="Authorization",required=false) String h){try{return ResponseEntity.ok(auth.byToken(token(h)));}catch(IllegalArgumentException e){return ResponseEntity.status(401).body(java.util.Map.of("message",e.getMessage()));}}
    @GetMapping("/user/{email}") public ResponseEntity<?> user(@PathVariable String email){return ResponseEntity.status(410).body(java.util.Map.of("message","Use /api/auth/me with the login token."));}
    @PostMapping("/logout") public ResponseEntity<?> logout(@RequestHeader(value="Authorization",required=false) String h){auth.logout(token(h));return ResponseEntity.ok(java.util.Map.of("message","Logged out"));}
    @GetMapping("/test") public java.util.Map<String,Object> test(){return java.util.Map.of("status","ok","service","CampusConnect API");}
    private String token(String h){if(h==null||!h.startsWith("Bearer ")) throw new IllegalArgumentException("Authentication required."); return h.substring(7).trim();}
}
