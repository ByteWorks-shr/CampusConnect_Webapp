package com.campus.campusconnect.repository;

import com.campus.campusconnect.model.UserAccount;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.Optional;

public interface UserAccountRepository extends JpaRepository<UserAccount, Long> {
    Optional<UserAccount> findByEmailIgnoreCase(String email);
    Optional<UserAccount> findBySessionToken(String sessionToken);
    boolean existsByEmailIgnoreCase(String email);
}
