"use strict";

/* ==========================================
   CAMPUSCONNECT CHAT
   File: Dashboard/Chat/chat.js
   Backend: Spring Boot REST API
   ========================================== */

const CHAT_CONFIG = {
    API_BASE_URL: "/api/chat",
    MAX_ATTACHMENT_SIZE: 10 * 1024 * 1024,
    MAX_MESSAGE_LENGTH: 5000
};

/*
Expected API routes:
GET    /me
GET    /groups
GET    /unread-count
GET    /groups/{groupId}/messages
POST   /groups/{groupId}/messages
POST   /groups/{groupId}/read
PATCH  /messages/{messageId}
DELETE /messages/{messageId}
GET    /messages/search?query=...
*/

/* ==========================================
   DOM ELEMENTS
   ========================================== */

const backButton = document.getElementById("backButton");
const searchToggle = document.getElementById("searchToggle");
const searchForm = document.getElementById("searchForm");
const searchInput = document.getElementById("searchInput");
const searchResults = document.getElementById("searchResults");

const groupList = document.getElementById("groupList");
const conversationEmpty = document.getElementById("conversationEmpty");
const conversationContent = document.getElementById("conversationContent");
const groupsBackButton = document.getElementById("groupsBackButton");

const groupTitle = document.getElementById("groupTitle");
const groupDescription = document.getElementById("groupDescription");
const messagesArea = document.getElementById("messagesArea");

const messageForm = document.getElementById("messageForm");
const messageInput = document.getElementById("messageInput");
const sendButton = document.getElementById("sendButton");

const attachmentButton = document.getElementById("attachmentButton");
const attachmentInput = document.getElementById("attachmentInput");
const attachmentPreview = document.getElementById("attachmentPreview");
const attachmentName = document.getElementById("attachmentName");
const removeAttachmentButton =
    document.getElementById("removeAttachmentButton");

const replyPreview = document.getElementById("replyPreview");
const replyText = document.getElementById("replyText");
const cancelReplyButton = document.getElementById("cancelReplyButton");

/* ==========================================
   APPLICATION STATE
   ========================================== */

let currentUser = null;
let groups = [];
let activeGroup = null;
let messages = [];

let selectedAttachment = null;
let replyToMessage = null;

let isSendingMessage = false;
let messageLoadVersion = 0;

/* ==========================================
   API HELPER
   ========================================== */

async function chatRequest(path, options = {}) {
    const requestOptions = {
        credentials: "same-origin",
        ...options,
        headers: { ...(options.headers || {}) }
    };

    if (
        requestOptions.body &&
        !(requestOptions.body instanceof FormData) &&
        typeof requestOptions.body !== "string"
    ) {
        requestOptions.body = JSON.stringify(requestOptions.body);
    }

    if (
        requestOptions.body &&
        !(requestOptions.body instanceof FormData) &&
        !requestOptions.headers["Content-Type"]
    ) {
        requestOptions.headers["Content-Type"] = "application/json";
    }

    const response = await fetch(
        CHAT_CONFIG.API_BASE_URL + path,
        requestOptions
    );

    if (response.status === 204) {
        return null;
    }

    const contentType = response.headers.get("content-type") || "";
    let data = null;

    if (contentType.includes("application/json")) {
        data = await response.json();
    } else {
        data = await response.text();
    }

    if (!response.ok) {
        const message =
            data && typeof data === "object"
                ? data.message || data.error
                : data;

        throw new Error(
            message || `Request failed (${response.status}).`
        );
    }

    return data;
}

/* ==========================================
   GENERAL HELPERS
   ========================================== */

function getList(data, keys = []) {
    if (Array.isArray(data)) {
        return data;
    }

    if (data && typeof data === "object") {
        for (const key of keys) {
            if (Array.isArray(data[key])) {
                return data[key];
            }
        }
    }

    return [];
}

function getGroupId(group) {
    return group?.id ?? group?.groupId ?? group?.group_id;
}

function getMessageId(message) {
    return (
        message?.id ??
        message?.messageId ??
        message?.message_id
    );
}

function getMessageContent(message) {
    return String(message?.content ?? message?.text ?? "");
}

function getSenderName(message) {
    return (
        message?.senderName ||
        message?.authorName ||
        message?.sender?.name ||
        message?.author?.name ||
        "CampusConnect member"
    );
}

function getGroupName(group) {
    return group?.name || group?.groupName || "Group";
}

function getGroupLastMessage(group) {
    const lastMessage = group?.lastMessage;

    if (typeof lastMessage === "string") {
        return lastMessage;
    }

    return (
        lastMessage?.content ||
        group?.description ||
        "Open group conversation"
    );
}

function formatTime(value) {
    if (!value) {
        return "";
    }

    const date = new Date(value);

    if (Number.isNaN(date.getTime())) {
        return "";
    }

    return date.toLocaleTimeString([], {
        hour: "2-digit",
        minute: "2-digit"
    });
}

function showMessage(
    element,
    message,
    className = "status-message"
) {
    if (!element) {
        return;
    }

    element.replaceChildren();

    const paragraph = document.createElement("p");
    paragraph.className = className;
    paragraph.textContent = message;

    element.appendChild(paragraph);
}

function createIcon(className) {
    const icon = document.createElement("i");
    icon.className = className;
    icon.setAttribute("aria-hidden", "true");

    return icon;
}

function createButton(label, iconClass, onClick) {
    const button = document.createElement("button");

    button.type = "button";
    button.className = "icon-button";
    button.setAttribute("aria-label", label);
    button.title = label;

    button.appendChild(createIcon(iconClass));
    button.addEventListener("click", onClick);

    return button;
}

function isOwnMessage(message) {
    if (!currentUser || !message) {
        return false;
    }

    const userId = currentUser.id ?? currentUser.userId;

    const senderId =
        message.senderId ??
        message.authorId ??
        message.sender?.id ??
        message.author?.id;

    return (
        userId != null &&
        senderId != null &&
        String(userId) === String(senderId)
    );
}

/* ==========================================
   CURRENT USER
   ========================================== */

async function loadCurrentUser() {
    const data = await chatRequest("/me");

    currentUser = data?.user || data;

    if (!currentUser || typeof currentUser !== "object") {
        throw new Error("Unable to load account information.");
    }

    return currentUser;
}

/* ==========================================
   LOAD GROUPS
   ========================================== */

async function loadGroups() {
    if (!groupList) {
        return;
    }

    try {
        const data = await chatRequest("/groups");

        groups = getList(data, [
            "groups",
            "content",
            "items"
        ]);

        renderGroups();
    } catch (error) {
        showMessage(
            groupList,
            "Unable to load groups. Please try again.",
            "error-message"
        );

        console.error("Group loading failed:", error);
    }
}

/* ==========================================
   RENDER GROUPS
   ========================================== */

function renderGroups() {
    if (!groupList) {
        return;
    }

    groupList.replaceChildren();

    if (groups.length === 0) {
        const empty = document.createElement("div");
        empty.className = "empty-state";

        empty.appendChild(
            createIcon("fa-solid fa-people-group")
        );

        const heading = document.createElement("h3");
        heading.textContent = "No groups available";

        const description = document.createElement("p");
        description.textContent =
            "Groups will appear here when they are available to your account.";

        empty.append(heading, description);
        groupList.appendChild(empty);
        return;
    }

    groups.forEach((group) => {
        const groupId = getGroupId(group);

        if (groupId == null) {
            return;
        }

        const button = document.createElement("button");
        button.type = "button";
        button.className = "group-item";

        if (
            activeGroup &&
            String(getGroupId(activeGroup)) === String(groupId)
        ) {
            button.classList.add("active");
        }

        const avatar = document.createElement("div");
        avatar.className = "group-avatar";
        avatar.appendChild(
            createIcon("fa-solid fa-people-group")
        );

        const details = document.createElement("div");
        details.className = "group-details";

        const name = document.createElement("h3");
        name.className = "group-name";
        name.textContent = getGroupName(group);

        const lastMessage = document.createElement("p");
        lastMessage.className = "group-last-message";
        lastMessage.textContent = getGroupLastMessage(group);

        details.append(name, lastMessage);

        const meta = document.createElement("div");
        meta.className = "group-meta";

        const time = document.createElement("span");
        time.className = "group-time";
        time.textContent = formatTime(
            group.lastMessageAt ||
            group.lastMessage?.createdAt ||
            group.updatedAt
        );

        meta.appendChild(time);

        const unread = Number(
            group.unreadCount ?? group.unreadMessages ?? 0
        );

        if (unread > 0) {
            const badge = document.createElement("span");
            badge.className = "group-unread-badge";
            badge.textContent = unread > 99 ? "99+" : String(unread);

            meta.appendChild(badge);
        }

        button.append(avatar, details, meta);

        button.addEventListener("click", () => {
            openGroup(group);
        });

        groupList.appendChild(button);
    });
}

/* ==========================================
   OPEN GROUP
   ========================================== */

async function openGroup(group) {
    if (!group || getGroupId(group) == null) {
        return;
    }

    activeGroup = group;
    replyToMessage = null;
    selectedAttachment = null;

    if (attachmentInput) {
        attachmentInput.value = "";
    }

    updateReplyPreview();
    updateAttachmentPreview();
    renderGroups();

    if (conversationEmpty) {
        conversationEmpty.hidden = true;
    }

    if (conversationContent) {
        conversationContent.hidden = false;
    }

    if (groupTitle) {
        groupTitle.textContent = getGroupName(group);
    }

    if (groupDescription) {
        groupDescription.textContent =
            group.description || "College group conversation";
    }

    showMessage(
        messagesArea,
        "Loading messages...",
        "loading-message"
    );

    if (window.matchMedia("(max-width: 760px)").matches) {
        document.querySelector(".groups-panel")
            ?.classList.add("mobile-hidden");

        document.querySelector(".conversation-panel")
            ?.classList.add("mobile-visible");
    }

    await loadMessages();
}

/* ==========================================
   LOAD MESSAGES
   ========================================== */

async function loadMessages() {
    if (!activeGroup) {
        return;
    }

    const groupId = getGroupId(activeGroup);

    if (groupId == null) {
        return;
    }

    const requestedGroupId = String(groupId);
    const requestVersion = ++messageLoadVersion;

    try {
        const data = await chatRequest(
            `/groups/${encodeURIComponent(groupId)}/messages`
        );

        if (
            requestVersion !== messageLoadVersion ||
            !activeGroup ||
            String(getGroupId(activeGroup)) !== requestedGroupId
        ) {
            return;
        }

        messages = getList(data, [
            "messages",
            "content",
            "items"
        ]);

        renderMessages();

        await markGroupAsRead(requestedGroupId);
    } catch (error) {
        if (requestVersion === messageLoadVersion) {
            showMessage(
                messagesArea,
                "Unable to load messages. Please try again.",
                "error-message"
            );
        }

        console.error("Message loading failed:", error);
    }
}

/* ==========================================
   RENDER MESSAGES
   ========================================== */

function renderMessages() {
    if (!messagesArea) {
        return;
    }

    messagesArea.replaceChildren();

    if (messages.length === 0) {
        const empty = document.createElement("div");
        empty.className = "empty-state";

        empty.appendChild(
            createIcon("fa-regular fa-comment")
        );

        const heading = document.createElement("h3");
        heading.textContent = "No messages yet";

        const description = document.createElement("p");
        description.textContent =
            "Start the conversation by sending a message.";

        empty.append(heading, description);
        messagesArea.appendChild(empty);
        return;
    }

    messages.forEach((message) => {
        const own = isOwnMessage(message);

        const wrapper = document.createElement("article");
        wrapper.className = own
            ? "message-row own-message"
            : "message-row";

        const bubble = document.createElement("div");
        bubble.className = "message-bubble";

        const sender = document.createElement("div");
        sender.className = "message-sender";
        sender.textContent = own ? "You" : getSenderName(message);

        bubble.appendChild(sender);

        const reply = message.replyTo || message.replyToMessage;

        if (reply) {
            const replyBlock = document.createElement("div");
            replyBlock.className = "message-reply-reference";

            const replySender = document.createElement("strong");
            replySender.textContent =
                reply.senderName ||
                reply.authorName ||
                "Previous message";

            const replyContent = document.createElement("p");
            replyContent.textContent =
                reply.content || "Message";

            replyBlock.append(replySender, replyContent);
            bubble.appendChild(replyBlock);
        }

        if (message.deleted) {
            const deleted = document.createElement("p");
            deleted.className = "deleted-message";
            deleted.textContent = "This message was deleted.";

            bubble.appendChild(deleted);
        } else {
            const content = getMessageContent(message);

            if (content) {
                const text = document.createElement("p");
                text.className = "message-text";
                text.textContent = content;

                bubble.appendChild(text);
            }

            const attachment =
                message.attachment ||
                message.file ||
                message.attachments?.[0];

            if (attachment) {
                renderMessageAttachment(bubble, attachment);
            }
        }

        const footer = document.createElement("div");
        footer.className = "message-footer";

        const time = document.createElement("span");
        time.className = "message-time";
        time.textContent = formatTime(
            message.createdAt ||
            message.timestamp ||
            message.sentAt
        );

        footer.appendChild(time);

        if (message.editedAt || message.edited) {
            const edited = document.createElement("span");
            edited.className = "message-edited";
            edited.textContent = "Edited";

            footer.appendChild(edited);
        }

        bubble.appendChild(footer);

        const actions = document.createElement("div");
        actions.className = "message-actions";

        actions.appendChild(
            createButton("Reply", "fa-solid fa-reply", () => {
                startReply(message);
            })
        );

        if (own && !message.deleted) {
            actions.appendChild(
                createButton("Edit message", "fa-solid fa-pen", () => {
                    editMessage(message);
                })
            );

            actions.appendChild(
                createButton("Delete message", "fa-solid fa-trash", () => {
                    deleteMessage(message);
                })
            );
        }

        wrapper.append(bubble, actions);
        messagesArea.appendChild(wrapper);
    });

    messagesArea.scrollTop = messagesArea.scrollHeight;
}

/* ==========================================
   MESSAGE ATTACHMENTS
   ========================================== */

function renderMessageAttachment(container, attachment) {
    const url =
        attachment.url ||
        attachment.downloadUrl ||
        attachment.fileUrl;

    const fileName =
        attachment.fileName ||
        attachment.name ||
        "Attachment";

    if (!url) {
        const label = document.createElement("div");
        label.className = "message-attachment";

        label.appendChild(
            createIcon("fa-solid fa-paperclip")
        );

        const text = document.createElement("span");
        text.textContent = fileName;

        label.appendChild(text);
        container.appendChild(label);
        return;
    }

    let safeUrl;

    try {
        safeUrl = new URL(url, window.location.origin);
    } catch {
        return;
    }

    if (!["http:", "https:"].includes(safeUrl.protocol)) {
        return;
    }

    const mimeType =
        attachment.contentType ||
        attachment.mimeType ||
        "";

    const isImage =
        mimeType.startsWith("image/") ||
        /\.(png|jpe?g|gif|webp|bmp)$/i.test(fileName);

    const link = document.createElement("a");
    link.className = "message-attachment";
    link.href = safeUrl.href;
    link.target = "_blank";
    link.rel = "noopener noreferrer";

    if (isImage) {
        const image = document.createElement("img");

        image.src = safeUrl.href;
        image.alt = fileName;
        image.className = "message-attachment-image";
        image.loading = "lazy";

        link.appendChild(image);
    } else {
        link.appendChild(
            createIcon("fa-solid fa-file-lines")
        );

        const text = document.createElement("span");
        text.textContent = fileName;

        link.appendChild(text);
    }

    container.appendChild(link);
}

/* ==========================================
   REPLY TO MESSAGE
   ========================================== */

function startReply(message) {
    replyToMessage = message;

    if (replyText) {
        replyText.textContent =
            getMessageContent(message) || "Attachment";
    }

    updateReplyPreview();
    messageInput?.focus();
}

function updateReplyPreview() {
    if (replyPreview) {
        replyPreview.hidden = !replyToMessage;
    }
}

if (cancelReplyButton) {
    cancelReplyButton.addEventListener("click", () => {
        replyToMessage = null;
        updateReplyPreview();
    });
}

/* ==========================================
   ATTACHMENTS
   ========================================== */

if (attachmentButton && attachmentInput) {
    attachmentButton.addEventListener("click", () => {
        attachmentInput.click();
    });
}

if (attachmentInput) {
    attachmentInput.addEventListener("change", () => {
        const file = attachmentInput.files?.[0];

        if (!file) {
            return;
        }

        if (file.size > CHAT_CONFIG.MAX_ATTACHMENT_SIZE) {
            alert("The attachment must be 10 MB or smaller.");

            attachmentInput.value = "";
            selectedAttachment = null;
            updateAttachmentPreview();
            return;
        }

        selectedAttachment = file;
        updateAttachmentPreview();
    });
}

function updateAttachmentPreview() {
    if (!attachmentPreview) {
        return;
    }

    attachmentPreview.hidden = !selectedAttachment;

    if (attachmentName) {
        attachmentName.textContent = selectedAttachment
            ? selectedAttachment.name
            : "";
    }
}

if (removeAttachmentButton) {
    removeAttachmentButton.addEventListener("click", () => {
        selectedAttachment = null;

        if (attachmentInput) {
            attachmentInput.value = "";
        }

        updateAttachmentPreview();
    });
}

/* ==========================================
   SEND MESSAGE
   ========================================== */

if (messageForm) {
    messageForm.addEventListener("submit", async (event) => {
        event.preventDefault();

        if (!activeGroup || isSendingMessage) {
            return;
        }

        const content = messageInput?.value.trim() || "";

        if (!content && !selectedAttachment) {
            messageInput?.focus();
            return;
        }

        if (content.length > CHAT_CONFIG.MAX_MESSAGE_LENGTH) {
            alert("Messages cannot exceed 5000 characters.");
            return;
        }

        const groupId = getGroupId(activeGroup);
        const formData = new FormData();

        formData.append("content", content);

        if (replyToMessage) {
            const replyId = getMessageId(replyToMessage);

            if (replyId != null) {
                formData.append(
                    "replyToMessageId",
                    String(replyId)
                );
            }
        }

        if (selectedAttachment) {
            formData.append("attachment", selectedAttachment);
        }

        isSendingMessage = true;

        if (sendButton) {
            sendButton.disabled = true;
        }

        try {
            await chatRequest(
                `/groups/${encodeURIComponent(groupId)}/messages`,
                {
                    method: "POST",
                    body: formData
                }
            );

            if (messageInput) {
                messageInput.value = "";
            }

            selectedAttachment = null;
            replyToMessage = null;

            if (attachmentInput) {
                attachmentInput.value = "";
            }

            updateAttachmentPreview();
            updateReplyPreview();

            await loadMessages();
            await loadGroups();
            await loadUnreadCount();
        } catch (error) {
            alert("Message could not be sent: " + error.message);

            console.error("Sending message failed:", error);
        } finally {
            isSendingMessage = false;

            if (sendButton) {
                sendButton.disabled = false;
            }
        }
    });
}

/* ==========================================
   EDIT MESSAGE
   ========================================== */

async function editMessage(message) {
    if (!isOwnMessage(message) || message.deleted) {
        return;
    }

    const messageId = getMessageId(message);

    if (messageId == null) {
        alert("Message ID is missing.");
        return;
    }

    const oldContent = getMessageContent(message);
    const updatedContent = prompt(
        "Edit your message:",
        oldContent
    );

    if (updatedContent === null) {
        return;
    }

    const content = updatedContent.trim();

    if (!content) {
        alert("Message cannot be empty.");
        return;
    }

    if (content.length > CHAT_CONFIG.MAX_MESSAGE_LENGTH) {
        alert("Messages cannot exceed 5000 characters.");
        return;
    }

    try {
        await chatRequest(
            `/messages/${encodeURIComponent(messageId)}`,
            {
                method: "PATCH",
                body: { content }
            }
        );

        await loadMessages();
    } catch (error) {
        alert("Unable to edit message: " + error.message);
    }
}

/* ==========================================
   DELETE MESSAGE
   ========================================== */

async function deleteMessage(message) {
    if (!isOwnMessage(message) || message.deleted) {
        return;
    }

    const messageId = getMessageId(message);

    if (messageId == null) {
        alert("Message ID is missing.");
        return;
    }

    if (!confirm("Delete this message?")) {
        return;
    }

    try {
        await chatRequest(
            `/messages/${encodeURIComponent(messageId)}`,
            { method: "DELETE" }
        );

        await loadMessages();
    } catch (error) {
        alert("Unable to delete message: " + error.message);
    }
}

/* ==========================================
   MARK GROUP AS READ
   ========================================== */

async function markGroupAsRead(groupId) {
    if (groupId == null) {
        return;
    }

    try {
        await chatRequest(
            `/groups/${encodeURIComponent(groupId)}/read`,
            { method: "POST" }
        );

        await loadUnreadCount();
    } catch (error) {
        console.error(
            "Mark-as-read request failed:",
            error
        );
    }
}

/* ==========================================
   UNREAD COUNT
   ========================================== */

async function loadUnreadCount() {
    try {
        const data = await chatRequest("/unread-count");

        const count = Number(
            data?.count ?? data?.unreadCount ?? 0
        );

        const badge = document.getElementById("chatUnreadBadge");

        if (badge) {
            badge.textContent = count > 99
                ? "99+"
                : String(count);

            badge.hidden = count <= 0;
        }
    } catch (error) {
        console.error(
            "Unread-count request failed:",
            error
        );
    }
}

/* ==========================================
   SEARCH MESSAGES
   ========================================== */

if (searchToggle && searchForm) {
    searchToggle.addEventListener("click", () => {
        searchForm.hidden = !searchForm.hidden;

        if (!searchForm.hidden) {
            searchInput?.focus();
        } else if (searchResults) {
            searchResults.hidden = true;
        }
    });
}

if (searchForm) {
    searchForm.addEventListener("submit", async (event) => {
        event.preventDefault();

        const query = searchInput?.value.trim();

        if (!query || !searchResults) {
            return;
        }

        const params = new URLSearchParams({ query });

        if (activeGroup) {
            params.set(
                "groupId",
                String(getGroupId(activeGroup))
            );
        }

        searchResults.hidden = false;

        showMessage(
            searchResults,
            "Searching...",
            "loading-message"
        );

        try {
            const data = await chatRequest(
                `/messages/search?${params.toString()}`
            );

            const results = getList(data, [
                "results",
                "messages",
                "content",
                "items"
            ]);

            renderSearchResults(results);
        } catch (error) {
            showMessage(
                searchResults,
                "Search failed. Please try again.",
                "error-message"
            );

            console.error("Message search failed:", error);
        }
    });
}

/* ==========================================
   RENDER SEARCH RESULTS
   ========================================== */

function renderSearchResults(results) {
    if (!searchResults) {
        return;
    }

    searchResults.replaceChildren();

    if (results.length === 0) {
        showMessage(
            searchResults,
            "No matching messages found."
        );
        return;
    }

    results.forEach((message) => {
        const item = document.createElement("button");

        item.type = "button";
        item.className = "search-result-item";

        const sender = document.createElement("strong");
        sender.textContent = getSenderName(message);

        const content = document.createElement("p");
        content.textContent = getMessageContent(message);

        item.append(sender, content);

        item.addEventListener("click", async () => {
            const groupId =
                message.groupId ??
                message.group?.id ??
                message.group?.groupId;

            const group = groups.find(
                (entry) =>
                    String(getGroupId(entry)) === String(groupId)
            );

            if (group) {
                await openGroup(group);
                searchResults.hidden = true;
            } else {
                alert(
                    "This message's group is not available in your group list."
                );
            }
        });

        searchResults.appendChild(item);
    });
}

/* ==========================================
   NAVIGATION
   ========================================== */

if (backButton) {
    backButton.addEventListener("click", () => {
        if (window.history.length > 1) {
            window.history.back();
        } else {
            window.location.href =
                "../Student/student-dashboard.html";
        }
    });
}

if (groupsBackButton) {
    groupsBackButton.addEventListener("click", () => {
        document.querySelector(".groups-panel")
            ?.classList.remove("mobile-hidden");

        document.querySelector(".conversation-panel")
            ?.classList.remove("mobile-visible");
    });
}
/* ==========================================
STUDENT BOTTOM NAVIGATION
========================================== */

const homeButton = document.getElementById("homeButton");
const modulesButton = document.getElementById("modulesButton");
const profileButton = document.getElementById("profileButton");

if (homeButton) {
    homeButton.addEventListener("click", () => {
        window.location.href = "../Student/student-dashboard.html";
    });
}

if (modulesButton) {
    modulesButton.addEventListener("click", () => {
        window.location.href = "../Student/modules.html";
    });
}

if (profileButton) {
    profileButton.addEventListener("click", () => {
        window.location.href = "../Student/profile.html";
    });
}
/* ==========================================
   INITIALIZATION
   ========================================== */

async function initializeChat() {
    try {
        await loadCurrentUser();
        await loadGroups();
        await loadUnreadCount();
    } catch (error) {
        console.error(
            "Chat initialization failed:",
            error
        );

        if (groupList) {
            showMessage(
                groupList,
                "Unable to connect to CampusConnect Chat. The backend API may not be available yet.",
                "error-message"
            );
        }
    }
}

initializeChat();