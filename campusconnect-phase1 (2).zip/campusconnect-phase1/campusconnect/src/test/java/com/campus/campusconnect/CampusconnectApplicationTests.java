package com.campus.campusconnect;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CampusconnectApplicationTests {

	@Test
	void contextLoads() {
	}

}
