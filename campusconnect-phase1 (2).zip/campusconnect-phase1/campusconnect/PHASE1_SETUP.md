# CampusConnect — Phase 1 Backend Integration

## What changed

Phase 1 connects the authentication/profile foundation to the Spring Boot backend.

- Added a `users` JPA entity for Student, Faculty and Admin accounts.
- Passwords are stored as BCrypt hashes instead of plaintext.
- Added register/login/logout/current-user APIs.
- Login creates an opaque session token and returns a safe user DTO (never the password).
- Frontend login and registration now use the same-origin `/api` base URL.
- Student profile/dashboard use `GET /api/auth/me` with the bearer token.
- Faculty and Admin profile pages now send the bearer token and can load their profile through backend endpoints.
- Database credentials are configurable through environment variables.

## Backend endpoints

- `POST /api/auth/register`
- `POST /api/auth/login`
- `GET /api/auth/me` — requires `Authorization: Bearer <token>`
- `POST /api/auth/logout` — requires `Authorization: Bearer <token>`
- `GET /api/auth/test`
- `GET /api/student/profile` — authenticated Student
- `GET /api/faculty/profile` — authenticated Faculty
- `GET /api/admin/profile` — authenticated Admin

## Database configuration

Copy `.env.example` values into your environment. The application expects:

- `DB_URL`
- `DB_USERNAME`
- `DB_PASSWORD`
- `SERVER_PORT` (optional, defaults to 8081)

Create the MySQL database first:

```sql
CREATE DATABASE campus_connect;
```

The project uses `spring.jpa.hibernate.ddl-auto=update`, so the new `users` table is created/updated automatically when the application starts.

## Run

From the project directory:

```bash
./mvnw spring-boot:run
```

On Windows:

```bat
mvnw.cmd spring-boot:run
```

Open:

```text
http://localhost:8081/login/login.html
```

## Phase 1 test order

1. Register a Student.
2. Confirm a row is created in `users` and `passwordHash` is not plaintext.
3. Login as that Student.
4. Confirm `campusConnectAuthToken` is stored in the browser.
5. Open Student Dashboard/Profile and confirm the name/email/profile data comes from `/api/auth/me`.
6. Register a Faculty and Admin account and verify their roles are stored correctly.
7. Confirm an Admin registration starts as `PENDING_APPROVAL` and cannot login until approved.

## Important limitation

Maven dependency resolution could not be executed in this environment because the Maven distribution/dependencies were unavailable offline. The Java sources were inspected and the modified JavaScript files were syntax-checked with Node.js. Run the Maven compile/tests locally before proceeding to Phase 2.
